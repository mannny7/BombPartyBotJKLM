import os
import random
import time
import keyboard

from selenium import webdriver
from selenium.webdriver.chrome import service as cs
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


words = []
joinable = False
sentWords = []
loops = 1

options = webdriver.ChromeOptions()
options.add_experimental_option("useAutomationExtension", False)
options.add_experimental_option("excludeSwitches", ["enable-automation"])

fileLocation = os.path.dirname(os.path.realpath(__file__))
filePath = fileLocation + "/chromedriver.exe"
chrome_service = cs.Service(
    executable_path=filePath)
driver = webdriver.Chrome()

words = []
joinable = False
sentWords = []
loops = 1

with open(fileLocation + "\\web2", "r") as file:
    for line in file:
        words.append(line[:len(line) - 1])


driver.get("https://www.jklm.fun")

while True:
    while True:
        try:
            driver.switch_to.frame(
                driver.find_element(By.XPATH,
                                    "//div[@class='game']/iframe[contains(@src,'jklm.fun')]"))  # Switch to correct iframe
        except:
            break

    while True:
        try:
            joinButton = driver.find_element(By.XPATH,
                                             "/html/body/div[2]/div[3]/div[1]/div[1]/button")
            joinGame(joinButton)
        except:
            break

    def joinGame(joinButton):
        time.sleep(2)
        joinButton.click()
    if keyboard.is_pressed("INSERT"):
        try:
            if not driver.find_element(By.XPATH,
                                                     "/html/body/div[2]/div[3]/div[2]/div[1]").is_displayed():
                matches = []
            syllable = driver.find_element(By.XPATH,
                                           "/html/body/div[2]/div[2]/div[2]/div[2]/div").text
            answerBox = driver.find_element(By.XPATH,
                                            "/html/body/div[2]/div[3]/div[2]/div[2]/form/input")
            for word in words:
                if syllable in word:
                    matches.append(word)
            sorted_matches = list(sorted(matches, key=len))
            choice = sorted_matches[0]
            repeated = True
            while repeated:
                if choice in sentWords:
                    choice = sorted_matches[loops]
                    loops += 1
                else:
                    repeated = False
            choice = ''.join(choice)
            sentWords.append(choice)
            answerBox.click()
            for char in choice:
                charCode = ord(char) + random.randint(-1, 1)
                randChance = random.randint(1, 100)
                if randChance > 8:
                    fail = False
                if fail:
                    answerBox.send_keys(chr(charCode))
                    time.sleep(random.randint(2, 5) / 100)
                    answerBox.send_keys(Keys.BACK_SPACE)
                    time.sleep(0.1)
                    answerBox.send_keys(char)
                else:
                    answerBox.send_keys(char)
                    time.sleep(random.randint(7, 9) / 100)
            time.sleep(0.1)
            answerBox.send_keys(Keys.RETURN)
            print("Sent word", choice)
        except:
            pass
    if keyboard.is_pressed("PAGEUP"):
        try:
            if not driver.find_element(By.XPATH,
                                       "/html/body/div[2]/div[3]/div[2]/div[1]").is_displayed():
                matches = []
            syllable = driver.find_element(By.XPATH,
                                           "/html/body/div[2]/div[2]/div[2]/div[2]/div").text
            answerBox = driver.find_element(By.XPATH,
                                            "/html/body/div[2]/div[3]/div[2]/div[2]/form/input")
            for word in words:
                if syllable in word:
                    matches.append(word)
            sorted_matches = list(sorted(matches, key=len))
            choice = sorted_matches[len(sorted_matches) - 1]
            repeated = True
            while repeated:
                if choice in sentWords:
                    choice = sorted_matches[len(sorted_matches) - loops]
                    loops += 1
                else:
                    repeated = False
            choice = ''.join(choice)
            sentWords.append(choice)
            answerBox.click()
            for char in choice:
                charCode = ord(char) + random.randint(-1, 1)
                randChance = random.randint(1, 100)
                if randChance > 8:
                    fail = False
                if fail:
                    answerBox.send_keys(chr(charCode))
                    time.sleep(random.randint(2, 5) / 100)
                    answerBox.send_keys(Keys.BACK_SPACE)
                    time.sleep(0.1)
                    answerBox.send_keys(char)
                else:
                    answerBox.send_keys(char)
                    time.sleep(random.randint(7, 9) / 100)
            time.sleep(0.1)
            answerBox.send_keys(Keys.RETURN)
            print("Sent word", choice)
        except:
            pass

